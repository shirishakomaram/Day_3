package demo;
import java.util.*;

public class Demo_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter any number :");
int b=sc.nextInt();
for(int i=1;i<=b;i++) {
	for(int j=1;j<=b;j++) {
		System.out.println(i+j);
	}
	
}
	}

}
