package demo;

import java.util.Scanner;

public class Demo_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter number :");
int x=sc.nextInt();
System.out.println("7th Tables :");
for(int i=1;i<=x;i++) {
	
System.out.println("7* " + i + " = " + (i*7));
	}

}
}